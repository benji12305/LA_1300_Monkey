﻿using System;
using System.Linq;
using System.IO;
using System.Collections;






namespace Vokabel
{





    class Program
    {
        static void Main(string[] args)
        {
            ArrayList erstesWort = new ArrayList();
            ArrayList zweitesWort = new ArrayList();
            int i = 0;
            bool Loop1 = true;
            bool Loop2 = true;
            bool Loop3 = true;
            string Voci = "";
            string outPath = @"..\..\..\..\englischvoci.txt";



            while (Loop2)
            {
                Console.WriteLine("Geben Sie das deutsche Wort ein.");
                erstesWort.Add(Console.ReadLine());
                Console.WriteLine("Geben Sie die dazugehörige Übersetzung in der Fremdsprache ein");
                zweitesWort.Add(Console.ReadLine());
                Loop1 = true;
                while (Loop1)
                {
                    Console.WriteLine("Noch ein Wort hinzufügen? [j/n]");
                    string Repeat = Console.ReadLine().ToLower();





                    switch (Repeat)
                    {
                        case "j":
                            Loop1 = false;
                            i++;
                            break;





                        case "n":
                            Loop1 = false;
                            Loop2 = false;





                            for (int b = 0; b < erstesWort.Count; b++)
                            {
                                Voci += erstesWort[b] + " " + zweitesWort[b] + Environment.NewLine;
                            }
                            File.WriteAllText(outPath, Voci);
                            break;





                        default:
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            Console.WriteLine("Ungültige Eingabe");
                            Console.ForegroundColor = ConsoleColor.White;





                            break;
                    }






                }





            }
            Console.WriteLine("Möchten Sie von deutsch in die Fremdsprache übersetzen [d], oder die Fremdsprache ins deutsche? [f]");
            while (Loop3)
            {
                string Order = Console.ReadLine().ToLower();
                switch (Order)
                {
                    case "d":
                        Eingabe(erstesWort, zweitesWort);
                        Loop3 = false;
                        break;





                    case "f":
                        Eingabe(zweitesWort, erstesWort);
                        Loop3 = false;
                        break;





                    default:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine("Ungültige Eingabe!");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                }
            }
        }
        static void Eingabe(ArrayList array1, ArrayList array2)
        {
            Console.Clear();
            int i = 0;
            int highscore = 0;
            Random Rand = new Random();
            int rand = 0;
            ArrayList zweiterVersuch = new ArrayList();
            ArrayList zweitesWort = new ArrayList();
            string Antwort = "";
            bool Loop = false;
            while (true)
            {
                try
                {
                    Console.WriteLine(array1[i]);
                }
                catch
                {
                    break;
                }
                Antwort = Console.ReadLine();





                if (Antwort == Convert.ToString(array2[i]))
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("Richtig.");
                    Console.ForegroundColor = ConsoleColor.White;
                    int Compare = Antwort.Length;





                    if (1 < Compare && Compare <= 4)
                    {
                        rand = Rand.Next(1, 10);
                    }
                    else if (4 < Compare && Compare <= 7)
                    {
                        rand = Rand.Next(10, 20);
                    }
                    else if (7 < Compare)
                    {
                        rand = Rand.Next(20, 30);
                    }



                    highscore = highscore + rand;





                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    Console.WriteLine("Falsch");
                    Console.ForegroundColor = ConsoleColor.White;
                    zweiterVersuch.Add(array1[i]);
                    zweitesWort.Add(array2[i]);
                    Loop = true;
                }
                i++;
            }
            int a = 0;
            while (Loop)
            {
                try
                {
                    Console.WriteLine(zweiterVersuch[a]);
                }
                catch
                {
                    break;
                }



                Antwort = Console.ReadLine();





                while (true)
                {
                    if (Antwort == Convert.ToString(zweitesWort[a]))
                    {
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("Richtig.");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine($"Die richtige Antwort wäre {zweitesWort[a]}, geben Sie das nochmal ein.");
                        Console.ForegroundColor = ConsoleColor.White;





                        Antwort = Console.ReadLine();
                    }
                }
                a++;
            }
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine($"Ihr Highscore: {highscore}");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}